import React from "react";
import { View, Text } from "react-native";


const Bookmark = () =>{
    return(
        <View>
            <Text>Bookmark</Text>
        </View>
    )
}

export default Bookmark
import React from "react";
import { View, Text } from "react-native";


const Create = () =>{
    return(
        <View>
            <Text>Create</Text>
        </View>
    )
}

export default Create
import {Text, View } from 'react-native';



export default function ProfilePage() {
  return (
    <View>
      <Text className='text-4xl text-center'>Profile to me</Text>
    </View>
  );
}
